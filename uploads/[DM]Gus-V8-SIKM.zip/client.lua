txd = engineLoadTXD ( "palm.txd" )
engineImportTXD ( txd, 622 )
dff = engineLoadDFF ( "palm.dff", 622 )
engineReplaceModel ( dff, 622 )
