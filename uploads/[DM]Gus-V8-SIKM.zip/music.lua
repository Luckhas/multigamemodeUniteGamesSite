music = playSound("song.ogg",true)
playing = true
outputChatBox(" ",0,0,0,true)
outputChatBox("#00ccffPress #ffffffM #00ccffto stop music",0,0,0,true)
outputChatBox(" ",0,0,0,true)
radio = getRadioChannel()
setRadioChannel(0)

function pause ()
volume = getSoundVolume(music)
if volume == 0 then
radio = getRadioChannel()
outputDebugString(radio)
setRadioChannel(0)
setSoundVolume(music,1)
playing = true
else
setSoundVolume(music,0)
playing = false
setRadioChannel(radio)
end
end

bindKey("M","down",pause)

function radioOff ()
if playing then
cancelEvent()
end
end
addEventHandler("onClientPlayerRadioSwitch",root,radioOff)