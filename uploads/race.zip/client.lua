function soundOnNitroTake ()
muza = playSound("audio/nitro.wav")
setTimer(function () stopSound(muza) end, 3000, 1)
end
addEvent("soundOnNitroTake", true)
addEventHandler("soundOnNitroTake", getRootElement(), soundOnNitroTake)

function soundOnRepairTake ()
muza = playSound("audio/repair.wav")
setTimer(function () stopSound(muza) end, 3000, 1)
end
addEvent("soundOnRepairTake", true)
addEventHandler("soundOnRepairTake", getRootElement(), soundOnRepairTake)

function soundOnVichelceTake ()
muza = playSound("audio/pickup.wav")
setTimer(function () stopSound(muza) end, 3000, 1)
end
addEvent("soundOnVichelceTake", true)
addEventHandler("soundOnVichelceTake", getRootElement(), soundOnVichelceTake)

addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), 
	function ()
		outputChatBox("", 255, 0, 0, true)
	end
)