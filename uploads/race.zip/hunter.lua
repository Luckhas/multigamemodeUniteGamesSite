function someoneReachedHunter(number, sort, model)
	if sort == "vehiclechange" and model == 425 then
	outputChatBox ( getPlayerName(source).." #FF6464[INFO]#ffffffObteve o hunter, Corra!", getRootElement(), 255, 255, 255, true )
		setWaterColor(255, 0, 0)
		setSkyGradient(87, 87, 87)
	elseif sort == "vehiclechange" and model == 520 then
	outputChatBox ( getPlayerName(source).." #FF6464[INFO]#ffffffObteve o hunter, Corra!, getRootElement(), 255, 255, 255, true )
		setWaterColor(255, 0, 0)
		setSkyGradient(87, 87, 87)
	elseif sort == "vehiclechange" and model == 447 then
	outputChatBox ( getPlayerName(source).." #FF6464[INFO]#ffffffObteve o hunter, Corra!", getRootElement(), 255, 255, 255, true )
		setWaterColor(255, 0, 0)
		setSkyGradient(87, 87, 87)
	elseif sort == "vehiclechange" and model == 464 then
	outputChatBox ( getPlayerName(source).." #FF6464[INFO]#ffffffObteve o hunter, Corra!", getRootElement(), 255, 255, 255, true )
		setWaterColor(255, 0, 0)
		setSkyGradient(87, 87, 87)
	end
end
addEvent("onPlayerPickUpRacePickup",true)
addEventHandler("onPlayerPickUpRacePickup",getRootElement(),someoneReachedHunter)
