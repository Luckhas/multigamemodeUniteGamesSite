function muzykanitrorepair(number, sort, model)
if sort == "nitro" then
triggerClientEvent(source, "soundOnNitroTake", getRootElement())
elseif sort == "repair" then
triggerClientEvent(source, "soundOnRepairTake", getRootElement())
elseif sort == "vehiclechange" then
triggerClientEvent(source, "soundOnVichelceTake", getRootElement())
end
end
addEvent("onPlayerPickUpRacePickup",true)
addEventHandler("onPlayerPickUpRacePickup",getRootElement(), muzykanitrorepair)