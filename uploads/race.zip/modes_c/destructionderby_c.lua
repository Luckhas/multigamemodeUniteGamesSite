﻿addEvent("onWins", true)
function drawNexMapString(player)
local x, y = guiGetScreenSize()
winner = dxText:create("#ECECEC"..getPlayerNametagText(player).." #ff0000 Bu Bolumun birincisi oldu!!!", x / 2, y / 2 - 10 + 75 - 41, false, "bankgothic", 1, "center")
nextmap = dxText:create( "#ff0000 Yeni map basliyor!:", x / 2, y / 2 - 10 + 75 + 11, false, "bankgothic", 1, "center")
winner:type('stroke', 1, 0, 0, 0, 255)
nextmap:type('stroke', 1, 0, 0, 0, 255)
local timerTime = 5
timer = dxText:create( tostring(timerTime), x / 2, y / 2 - 10 + 75 + 41, false, "bankgothic", 1, "center")
timer:type('stroke', 1, 0, 0, 0, 255)
setTimer(function()timerTime = timerTime - 1 timer:text(tostring(timerTime)) end, 1000, 4)
setTimer(function()winner:visible(false) nextmap:visible(false) timer:visible(false)end, 5500, 1)
end
addEventHandler("onWins", getRootElement(), drawNexMapString)

function dxDrawColorText(str, ax, ay, bx, by, color, scale, font)
  local pat = "(.-)#(%x%x%x%x%x%x)"
  local s, e, cap, col = str:find(pat, 1)
  local last = 1
  while s do
    if cap == "" and col then color = tocolor(tonumber("0x"..col:sub(1, 2)), tonumber("0x"..col:sub(3, 4)), tonumber("0x"..col:sub(5, 6)), 255) end
    if s ~= 1 or cap ~= "" then
      local w = dxGetTextWidth(cap, scale, font)
      dxDrawText(cap, ax, ay, ax + w, by, color, scale, font)
      ax = ax + w
      color = tocolor(tonumber("0x"..col:sub(1, 2)), tonumber("0x"..col:sub(3, 4)), tonumber("0x"..col:sub(5, 6)), 255)
    end
    last = e + 1
    s, e, cap, col = str:find(pat, last)
  end
  if last <= #str then
    cap = str:sub(last)
    local w = dxGetTextWidth(cap, scale, font)
    dxDrawText(cap, ax, ay, ax + w, by, color, scale, font)
  end
end