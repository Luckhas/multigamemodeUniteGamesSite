function somethingfor()

	if (getTickCount() - getTickStart > 3000 and count == 0) or (getTickCount() - getTickStart > 3000 and count == 1) then
		if count == 0 then
			sound3 = playSound( "3.mp3", false )
			count = 1
		end
		local elapsedTime = getTickCount() - (getTickStart+3000)
		local duration = (getTickStart+4000) - (getTickStart+3000)
		local progress = elapsedTime / duration
		local x, y, z = interpolateBetween ( 
			x1, y1, z1,
			x2, y2, z2, 
			progress, "InOutQuad")
		local r, _, _ = interpolateBetween ( 
			0, 0, 0,
			90, 0, 0, 
			progress, "InOutQuad")

		setCameraMatrix( x, y, z, lx, ly, lz, r, 0)
		if getTickCount() - getTickStart > 4000 and count == 1 then
			stopSound( sound3 )
			sound2 = playSound( "2.mp3", false )
			count = 2
			setCameraMatrix( x2, y2, z2, lx, ly, lz, 90, 0)
		end
	elseif getTickCount() - getTickStart > 4000 and count == 2 then
		local elapsedTime = getTickCount() - (getTickStart+4000)
		local duration = (getTickStart+5000) - (getTickStart+4000)
		local progress = elapsedTime / duration
		local r, t, _ = interpolateBetween ( 
			90, 50, 0,
			0, 100, 0, 
			progress, "InOutQuad")
		setCameraMatrix( x2, y2, z2, lx, ly, lz, r, t)

		if getTickCount() - getTickStart > 5000 and count == 2 then
			stopSound( sound2 )
			sound1 = playSound( "1.mp3", false )
			count = 3
			setCameraMatrix( x2, y2, z2, lx, ly, lz, r, t)
		end
	elseif (getTickCount() - getTickStart > 5000 and count == 3) or (getTickCount() - getTickStart > 5000 and count == 4) then
		local elapsedTime = getTickCount() - (getTickStart+5000)
		local duration = (getTickStart+6000) - (getTickStart+5000)
		local progress = elapsedTime / duration
		local r, _, _ = interpolateBetween ( 
			100, 0, 0,
			50, 0, 0, 
			progress, "InOutQuad")
		setCameraMatrix( x2, y2, z2, lx, ly, lz, 0, r)
		if count == 3 then
			count = 4
			fadeCamera ( false, 1.0, 0, 0, 0 )
		end
		if getTickCount() - getTickStart > 6000 and count == 4 then
			stopSound( sound1 )
			sound0 = playSound( "0.mp3", false )
			count = 5
			setCameraTarget ( getLocalPlayer() )
			fadeCamera ( true, 2.0, 0, 0, 0 )
		end
	elseif getTickCount() - getTickStart > 7500 and count == 5 then
		count = 6
		removeEventHandler( "onClientRender", getRootElement(), somethingfor)
		stopSound( sound0 )
	end
end

function getPositionInFrontOfElement(element, x, y, z)
	local matrix = getElementMatrix ( element )
	local offX = x * matrix[1][1] + y * matrix[2][1] + z * matrix[3][1] + 1 * matrix[4][1]
	local offY = x * matrix[1][2] + y * matrix[2][2] + z * matrix[3][2] + 1 * matrix[4][2]
	local offZ = x * matrix[1][3] + y * matrix[2][3] + z * matrix[3][3] + 1 * matrix[4][3]
	return offX, offY, offZ
end

function GridCountdown()
	count = 0
	getTickStart = getTickCount ()
	x1, y1, z1, lx1, ly1, lz1 = getCameraMatrix()
	x2,y2,z2 = getPositionInFrontOfElement(getPedOccupiedVehicle(getLocalPlayer()), 0, -5, 0)
	lx, ly, lz =getElementPosition(getPedOccupiedVehicle(getLocalPlayer()))
	addEventHandler( "onClientRender", getRootElement(), somethingfor)
end
addEvent ( "triggerclientforGridCountdown", true )
addEventHandler ( "triggerclientforGridCountdown", getRootElement(), GridCountdown )