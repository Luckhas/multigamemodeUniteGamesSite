function mapStateChange ( newState )
        if newState == "GridCountdown" then
		triggerClientEvent ( "triggerclientforGridCountdown", getRootElement() )
        end
end
addEvent ( "onRaceStateChanging", true )
addEventHandler ( "onRaceStateChanging", getRootElement(), mapStateChange )